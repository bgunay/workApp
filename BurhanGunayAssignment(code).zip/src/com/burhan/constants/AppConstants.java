package com.burhan.constants;

public interface AppConstants {
	public int THREAD_SIZE = 20;
	public String APP_NAME = "Customer Search Service";

	public String COLUMN0 = "Idx";
	public String COLUMN1 = "Customer Number";
	public String COLUMN2 = "Debt Payment Amount";
	public String COLUMN3 = "Last Payment Date";
	public String COLUMN4 = "Period/Year";
	public String COLUMN5 = "Invoice Number";
	public int ZERO = 0;
	public String BTN_EXPORT_VAL = "Export Filtered Customers";

	public int CUSTOMER_NO_START_IDX = 1;
	public int CUSTOMER_NO_END_IDX = 10;
	public int DEBT_AMOUNT_START_IDX = 18;
	public int DEBT_AMOUNT_END_IDX = 33;
	public int LAST_PAYMENT_DATE_START_IDX = 33;
	public int LAST_PAYMENT_DATE_END_IDX = 43;
	public int PERIOD_YEAR_START_IDX = 46;
	public int PERIOD_YEAR_END_IDX = 50;
	public int INVOICE_NO_START_IDX = 50;
	public int INVOICE_NO_END_IDX = 61;
}
