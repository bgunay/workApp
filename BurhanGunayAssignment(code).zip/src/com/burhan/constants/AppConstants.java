package com.burhan.constants;

public interface AppConstants {
	public int THREAD_SIZE = 20;
	public String APP_NAME = "Customer Search Service";

	public String COLUMN0 = "Idx";
	public String COLUMN1 = "Customer Number";
	public String COLUMN2 = "Debt Payment Amount";
	public String COLUMN3 = "Last Payment Date";
	public String COLUMN4 = "Period/Year";
	public String COLUMN5 = "Invoice Number";
	public int ZERO = 0;
	public String BTN_EXPORT_VAL = "Export Selected Customers";

}
