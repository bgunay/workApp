package com.burhan.entity;

import java.util.Date;

public class Customer {
	private Integer rowId;
	private String customerNumber;
	private Double debtPaymentAmount;
	private Date lastPaymentDate;
	private String periodYear;
	private String invoiceNumber;

	public String getCustomerNumber() {
		return customerNumber;
	}

	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}

	public Double getDebtPaymentAmount() {
		return debtPaymentAmount;
	}

	public void setDebtPaymentAmount(Double debtPaymentAmount) {
		this.debtPaymentAmount = debtPaymentAmount;
	}

	public Date getLastPaymentDate() {
		return lastPaymentDate;
	}

	public void setLastPaymentDate(Date lastPaymentDate) {
		this.lastPaymentDate = lastPaymentDate;
	}

	public String getPeriodYear() {
		return periodYear;
	}

	public void setPeriodYear(String periodYear) {
		this.periodYear = periodYear;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public Integer getRowId() {
		return rowId;
	}

	public void setRowId(Integer rowId) {
		this.rowId = rowId;
	}

}
