package com.burhan.service;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import org.apache.log4j.Logger;
import org.jdesktop.swingx.JXFrame;
import org.jdesktop.swingx.JXTable;

import com.burhan.constants.AppConstants;
import com.burhan.entity.Customer;

public class ComponentService {

	// our main swing frame
	JXFrame frame;
	JXTable customerTable;
	// this type keeps values (customerNumber:[rowIds]) will be used for search
	// we use this type for collecting map like ({customerNumber:
	// {1,2,3,66,74,77}})
	Map<String, Set<Integer>> customerNumbers = new HashMap<String, Set<Integer>>();
	// used for writing asynchronous write to table (per thread)

	// this service is written for file read operations.
	FileOperationService fileService = new FileOperationService();
	Logger logger = Logger.getLogger(this.getClass());
	private TableRowSorter<TableModel> rowSorter;
	private final static Object lock1 = new Object();
	private JTextField jtfFilter = new JTextField();
	private JButton exportButton = new JButton(AppConstants.BTN_EXPORT_VAL);

	/*
	 * 
	 */

	public void createTable() {
		JPanel panel = new JPanel();
		String[] columns = { AppConstants.COLUMN0, AppConstants.COLUMN1, AppConstants.COLUMN2, AppConstants.COLUMN3,
				AppConstants.COLUMN4, AppConstants.COLUMN5 };
		DefaultTableModel model = new DefaultTableModel(columns, AppConstants.ZERO);
		customerTable = new JXTable(model);
		customerTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		customerTable.setColumnControlVisible(true);
		customerTable.setVisibleColumnCount(6);
		customerTable.packAll();
		customerTable.setAutoResizeMode(JXTable.AUTO_RESIZE_OFF);
		// here is we make scrollable panel for our table
		JScrollPane pane = new JScrollPane(customerTable);
		JTableHeader header = customerTable.getTableHeader();
		header.setBackground(Color.yellow);
		panel.add(pane);
		panel.add(exportButton);
		panel.setBounds(0, 50, 550, 500);
		getFrame().add(panel);
	}

	public void showAndLoadData() {
		getFrame().setSize(600, 500);
		getFrame().setLayout(new BorderLayout());
		getFrame().setVisible(true);
		getFrame().setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		loadData();
	}

	// Callable thread
	class CallableThread implements Callable<Integer> {
		@Override
		public Integer call() {
			int cnt = 0;
			for (; cnt < 5; cnt++) {
				System.out.println("call:" + cnt);
			}
			return cnt;
		}
	}

	public void fillTableAsync(List<Customer> customerList) {
		synchronized (lock1) {
			DefaultTableModel model = (DefaultTableModel) getCustomerTable().getModel();
			Customer cust;
			for (int i = 0; i < customerList.size(); i++) {
				try {
					cust = customerList.get(i);
					model.addRow(new Object[] { cust.getRowId(), cust.getCustomerNumber(), cust.getDebtPaymentAmount(),
							cust.getLastPaymentDate(), cust.getPeriodYear(), cust.getInvoiceNumber() });
					// set rowId for this customer
					if (!customerNumbers.containsKey(cust.getCustomerNumber())) {
						Set<Integer> setOfIds = new HashSet<Integer>();
						setOfIds.add(cust.getRowId());
						customerNumbers.put(cust.getCustomerNumber(), setOfIds);
					} else {
						customerNumbers.get(cust.getCustomerNumber()).add(cust.getRowId());
					}
				} catch (Exception e) {
					logger.info("Error while filling table! " + e.getMessage());
				}
			}
		}
	}

	/*
	 * load file data to customerTable with specified thread size we are using
	 * 20 threads for optimal speed
	 */
	public void loadData() {
		try {
			fileService.setCompService(this);
			fileService.setFile(new File("content.txt"));
			// startProcess with given thread size
			fileService.processAndFillTable(AppConstants.THREAD_SIZE);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/*
	 * inits main Jframe and search input components
	 */
	public void initFrame() {
		JPanel panel = new JPanel(new BorderLayout());
		panel.add(new JLabel("Specify a word to match:"), BorderLayout.WEST);
		panel.add(jtfFilter, BorderLayout.CENTER);
		panel.add(exportButton, BorderLayout.WEST);
		getFrame().getContentPane().add(panel, BorderLayout.SOUTH);
		getFrame().pack();

		exportButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object[][] data = getTableData(getCustomerTable());
				buildHtmlTableAndExport(data);
			}

		});

		// we are adding listener for filtering table with jtfFilter input.
		jtfFilter.getDocument().addDocumentListener(new DocumentListener() {
			Set<Integer> rowsToShow = new HashSet<Integer>();

			private Set<Integer> filterRows(String text) {
				boolean isMatchded = false;
				Set<Integer> lines = new HashSet<Integer>();
				for (String customerNumber : customerNumbers.keySet()) {
					isMatchded = customerNumber.toLowerCase().matches("(.*)" + text + "(.*)");
					if (isMatchded) {
						lines.addAll(customerNumbers.get(customerNumber));
					}
				}
				return lines;
			}

			RowFilter<Object, Object> rowIndexFilter = new RowFilter<Object, Object>() {
				public boolean include(Entry entry) {
					Integer rowIndex = (Integer) entry.getValue(0);
					return rowsToShow.contains(rowIndex);
				}
			};

			@Override
			public void insertUpdate(DocumentEvent e) {
				String text = jtfFilter.getText();
				if (text.trim().length() != 0) {
					rowsToShow = filterRows(text);
					if (rowsToShow != null)
						getCustomerTable().setRowFilter(rowIndexFilter);
					DefaultTableModel dm = (DefaultTableModel) getCustomerTable().getModel();
					dm.fireTableDataChanged(); // notifies the JTable that the
												// model has changed

				} else {
					getCustomerTable().setRowFilter(null);
				}
			}

			@Override
			public void removeUpdate(DocumentEvent e) {
				String text = jtfFilter.getText();
				if (text.trim().length() != 0) {
					rowsToShow = filterRows(text);
					if (rowsToShow != null)
						getCustomerTable().setRowFilter(rowIndexFilter);
				} else {
					getCustomerTable().setRowFilter(null);
				}
			}

			@Override
			public void changedUpdate(DocumentEvent e) {
				throw new UnsupportedOperationException("Not supported yet.");
			}

		});
	}

	public Object[][] getTableData(JXTable table) {
		JXTable jxTable = table = getCustomerTable();
		int nRow = table.getRowCount();
		int nCol = table.getColumnCount();
		Object[][] tableData = new Object[nRow][nCol];
		for (int i = 0; i < nRow; i++)
			for (int j = 0; j < nCol; j++)
				tableData[i][j] = jxTable.getValueAt(i, j);
		return tableData;
	}

	public void buildHtmlTableAndExport(Object[][] objects) {
		StringBuilder buf = new StringBuilder();
		buf.append("<html>" + "<body>" + "<table>" + "<tr>" + "<th>" + AppConstants.COLUMN0 + "</th>" + "<th>"
				+ AppConstants.COLUMN1 + "</th>" + "<th>" + AppConstants.COLUMN2 + "</th>" + "<th>"
				+ AppConstants.COLUMN3 + "</th>" + "<th>" + AppConstants.COLUMN4 + "</th>" + "<th>"
				+ AppConstants.COLUMN5 + "</th>");
		for (int i = 0; i < objects.length; i++) {
			buf.append("<tr>").append("<td>").append(objects[i][0]).append("</td>").append("<td>").append(objects[i][1])
					.append("</td>").append("<td>").append(objects[i][2]).append("</td>").append("<td>")
					.append(objects[i][3]).append("</td>").append("<td>").append(objects[i][4]).append("</td>")
					.append("<td>").append(objects[i][5]).append("</td>").append("</tr>");
		}
		buf.append("</table>" + "</body>" + "</html>");
		fileService.saveToFile(buf.toString());
	}

	public JXFrame getFrame() {
		return frame;
	}

	public void setFrame(JXFrame frame) {
		this.frame = frame;
	}

	public JXTable getCustomerTable() {
		return customerTable;
	}

	public void setCustomerTable(JXTable customerTable) {
		this.customerTable = customerTable;
	}

	public void showFinishMessage(int size, long duration) {
		JOptionPane.showMessageDialog(null, "Read " + size + " rows from file in " + duration + " milliseconds.");
	}

}
