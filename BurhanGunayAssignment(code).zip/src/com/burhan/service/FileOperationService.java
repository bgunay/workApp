package com.burhan.service;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.apache.log4j.Logger;

import com.burhan.entity.Customer;
import com.burhan.filereader.ConcurrentFileReader;

public class FileOperationService {

	Logger logger = Logger.getLogger(this.getClass());

	ConcurrentFileReader reader;
	// this service used when read completes to write to swing table
	ComponentService compService;

	// file to be read
	public void setFile(File file) throws IOException {
		reader = new ConcurrentFileReader(file);
	}

	// Processes the given portion of the file.
	// Called simultaneously from several threads.
	// Use your custom return type as needed, I used String just to give an
	// example.
	public SortedMap<Integer, String> processLines(int start, int lineCount) throws Exception {
		SortedMap<Integer, String> lines = reader.readLines(start, lineCount);
		return lines;
	}

	// Creates a task that will process the given portion of the file,
	// when executed.
	public Callable<SortedMap<Integer, String>> processPartTask(final int start, final int lineCount) {
		return new Callable<SortedMap<Integer, String>>() {
			public SortedMap<Integer, String> call() throws Exception {
				return processLines(start, lineCount);
			}
		};
	}

	// Splits the computation into chunks of the given size,
	// creates appropriate tasks and runs them using a
	// given number of threads.
	public SortedMap<Integer, String> processAndFillTable(int threadSize) {
		int lineCountOfFile = reader.getLineCount();
		SortedMap<Integer, String> allLines = new TreeMap<Integer, String>();
		long startTime = System.currentTimeMillis();
		try {
			List<Callable<SortedMap<Integer, String>>> tasks = new ArrayList<Callable<SortedMap<Integer, String>>>(
					threadSize);
			int lineSizePerThread = lineCountOfFile / threadSize + 1;
			int to;
			int from;
			for (int i = 0; i < threadSize - 1; i++) {
				from = i * lineSizePerThread + 1;
				to = from + lineSizePerThread - 1;
				tasks.add(processPartTask(from, to));
				System.out.println("task added");
			}
			ExecutorService es = Executors.newFixedThreadPool(10);
			List<Future<SortedMap<Integer, String>>> results;
			results = es.invokeAll(tasks);
			es.shutdown();
			// use the results for something
			for (Future<SortedMap<Integer, String>> result : results) {
				SortedMap<Integer, String> lines = result.get();
				fillComponentWithData(lines);
				allLines.putAll(lines);
			}
			long finishTime = System.currentTimeMillis();
			showFinishMessage(allLines.size(), finishTime);
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return allLines;
	}

	private void showFinishMessage(int size, long duration) {
		compService.showFinishMessage(size, duration);
	}

	private void fillComponentWithData(SortedMap<Integer, String> lines) {
		List<Customer> customerList = new ArrayList<Customer>();
		Customer customer = new Customer();
		DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		for (int i = lines.firstKey(); i <= lines.firstKey() + lines.size() - 1; i++) {
			try {
				customer = new Customer();
				customer.setCustomerNumber(lines.get(i).substring(1, 1 + 9));
				customer.setDebtPaymentAmount(Double.valueOf(lines.get(i).substring(18, 18 + 15)));
				customer.setLastPaymentDate((Date) formatter.parse(lines.get(i).substring(33, 33 + 10)));
				customer.setPeriodYear(lines.get(i).substring(46, 46 + 4));
				customer.setInvoiceNumber(lines.get(i).substring(50, 50 + 11));
				customer.setRowId(i);
				customerList.add(customer);
			} catch (Exception e) {
				logger.info("Error at line" + i + " while fill table!. " + e.getMessage());
			}
		}
		compService.fillTableAsync(customerList);
	}

	public ComponentService getCompService() {
		return compService;
	}

	// fileOperationService is used with componentService, componentservices is
	// used to fill table in this service
	public void setCompService(ComponentService compService) {
		this.compService = compService;
	}

	public void saveToFile(String string, int length) {
		BufferedWriter writer = null;
		try {
			writer = new BufferedWriter(new FileWriter("selectedCustomers.html"));
			writer.write(string);
		} catch (IOException e) {
			System.err.println(e);
		} finally {
			if (writer != null) {
				try {
					writer.close();
					getCompService().showExportFinishMessage(length);
				} catch (IOException e) {
					System.err.println(e);
				}
			}
		}

	}

}
