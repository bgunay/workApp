package com.burhan.swingApp;

import javax.swing.JFrame;

import org.jdesktop.swingx.JXFrame;

import com.burhan.constants.AppConstants;
import com.burhan.service.ComponentService;

public class CustomerUIApp {

	// this service is responsible for build UI and UI related operations.
	ComponentService compService = new ComponentService();

	// startPoint of application.
	CustomerUIApp() {
		JFrame.setDefaultLookAndFeelDecorated(true);
		JXFrame f = new JXFrame(AppConstants.APP_NAME);
		compService.setFrame(f);
		compService.createTable();
		compService.initFrame();
		compService.showAndLoadData();
	}

	public static void main(String[] args) {
		new CustomerUIApp();
	}

}